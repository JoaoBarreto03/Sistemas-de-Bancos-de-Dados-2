-- --------  << aula1exer2Evolucao5 >>  ----------
--
--         SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 04/10/2023
-- Autor(es) ..............: JoaoNeto
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2Evolucao5
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--         => 01 View
--         => 05 Consultas
--
-- ---------------------------------------

-- TABELAS
DROP TABLE possui;
DROP TABLE telefone;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE AREA;
DROP TABLE GERENTE;
DROP TABLE EMPREGADO;
DROP TABLE PESSOA;
DROP SEQUENCE sqArea;
DROP SEQUENCE sqVenda;

