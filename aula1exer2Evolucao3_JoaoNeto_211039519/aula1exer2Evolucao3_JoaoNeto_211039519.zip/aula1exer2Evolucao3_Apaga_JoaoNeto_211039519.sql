-- << aula1exer2Evolucao3 >>
-- 
-- 			SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 11/09/2023
-- Autor(es) ..............: Leonardo Vitoriano e Joao Neto
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2Evolucao3
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- ---------------------------------------------------------

USE aula1exer2Evolucao3;

DROP TABLE possui;
DROP TABLE telefone;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE EMPREGADO;
DROP TABLE AREA;
DROP TABLE GERENTE;
DROP TABLE PESSOA;
